
clear all
close all

color = 0;
% ----------------------------- get jpeg file paths --------------------

'getting image paths...'

                                if color ==0
                                    path = ['../library_images/graffiti_256_black_white/']; 
                                else
                                    path = ['C:\Americano\library_images\graffiti_256_color\'];
                                end


                                % files = dir('C:\Image_registration\flickr_spider\graffiti_library\*.jpg');                    % get file names
                                directories = dir(path);                    % get directory names

                                num_files = 0;
                                file_count = 0;

                                dir_temp = directories(3).name;        % get first directory name
                                files = dir([path,dir_temp,'/*.jpg']);     % get file names for first directory
                                file_count = length(files);

                                % add directory path to jpeg files name
                                for j=1:length(files)
                                    files(j).name = [path,dir_temp,'/',files(j).name];
                                end

                                for i=2:(length(directories)-2)         % offset by 2 because first two entries are '.' and '..'


                                    dir_temp = directories(i+2).name;        % get next directory name

                                    files_temp = dir([path,dir_temp,'/*.jpg']);     % get file names for given directory

                                    % add directory path to jpeg files name
                                    for j=1:length(files_temp)
                                        files_temp(j).name = [path,dir_temp,'/',files_temp(j).name];
                                    end



                                    % concatenate file paths from next directory to existing 
                                    files((file_count+1):(file_count+length(files_temp))) = files_temp;


                                    file_count = file_count+length(files_temp);
                                %     pause
                                end

% bins = 16;
% hist_x = [(255/bins)/2:255/bins:(255-(255/bins)/2)];
% hist_matrix = zeros(length(files),bins);

% radial_freq = 6;
% angular_freq = 6;
% vector_len = radial_freq*angular_freq;
std_matrix = zeros(length(files),1);
%   gfd_matrix = zeros(8000,vector_len);
  
size_v = [128 128];

% avg_gfd = zeros(radial_freq,angular_freq);

for i=1:length(files)
    
    i
    
    
    Im_lib = imread([files(i).name]);      % read in library image
    
    Im_lib = imresize(Im_lib,size_v);    % resize image to 128
    
    std_lib = std2(Im_lib);
    
    std_matrix(i) = std_lib;
    
%         figure(1),subplot(2,1,1),imshow(Im_lib)
%     subplot(2,1,2),imshow(Im_lib)
%     subplot(3,1,3),mesh(I1_fm)
    
    
%     figure(1),subplot(1,2,1),imshow(Im_lib)
%     subplot(1,2,2),mesh(I1_fm);
%     pause
        
%     subplot(1,2,1),imshow(Im_lib)
%     subplot(1,2,2),plot(histo)

    
end
% pause

% std_matrix = single(gfd_matrix);
save('std_matrix_graffiti_128', 'std_matrix')
% save('std_matrix_SF_128', 'std_matrix')



