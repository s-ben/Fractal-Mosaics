
clear all
close all

color = 0;
% ----------------------------- get jpeg file paths --------------------

'getting image paths...'

                                if color ==0
                                    path = ['../library_images/graffiti_256_black_white/']; 
                                else
                                    path = ['C:\Americano\library_images\graffiti_256_color\'];
                                end


                                % files = dir('C:\Image_registration\flickr_spider\graffiti_library\*.jpg');                    % get file names
                                directories = dir(path);                    % get directory names

                                num_files = 0;
                                file_count = 0;

                                dir_temp = directories(3).name;        % get first directory name
                                files = dir([path,dir_temp,'/*.jpg']);     % get file names for first directory
                                file_count = length(files);

                                % add directory path to jpeg files name
                                for j=1:length(files)
                                    files(j).name = [path,dir_temp,'/',files(j).name];
                                end

                                for i=2:(length(directories)-2)         % offset by 2 because first two entries are '.' and '..'


                                    dir_temp = directories(i+2).name;        % get next directory name

                                    files_temp = dir([path,dir_temp,'/*.jpg']);     % get file names for given directory

                                    % add directory path to jpeg files name
                                    for j=1:length(files_temp)
                                        files_temp(j).name = [path,dir_temp,'/',files_temp(j).name];
                                    end



                                    % concatenate file paths from next directory to existing 
                                    files((file_count+1):(file_count+length(files_temp))) = files_temp;


                                    file_count = file_count+length(files_temp);
                                %     pause
                                end

DC_v = zeros(length(files),1);

for z=1:length(files)

%     z
    Im_lib = imread([files(z).name]);      % read in library image

    DC_component = sum(sum(Im_lib))/(256*256);

    DC_v(z) = DC_component;


end

save DC_vals_graffiti DC_v
