
clear all

load Fractal_Mosaic    % load Matlab workspace with mosaic parameters

black_bg = 0;       % determines if a black background is used or the original target image.  '1' = use target image as background


color_render = 1;      % If color_render = '1', use color images, even if matching was done in black and white mode.  If color ='0', use black and white images


perc_sloped = 0.1;

I1 = imread(target_path);

size_r = size(Render_target);

I1 = imresize(I1, [size_r(1) size_r(2)]);
% I1 = imresize(I1, [8192 8192]);
Render_target = I1;
clear I1


pat = '\';
regexprep(path, pat, '/')

if black_bg == 1
    'overlaying on target image'
else
    Render_target(:,:,:) = 0;
end

%---------- calculate distance windows -----------


for i=1:length(level_v)
%     i
    
    perc_sloped_fixed = 0.01;%.1;            % perc sloped for fixed window (one that's used to cut off clipping)
    
    fd = zeros(lib_im_v(i));
    fd_fixed = zeros(lib_im_v(i));

    y_d = ones(1,lib_im_v(i)/2);
    y_d_fixed = ones(1,lib_im_v(i)/2);
    
    x_ind = linspace(0,lib_im_v(i)/2,lib_im_v(i)/2);
    for u=1:(perc_sloped*(lib_im_v(i)/2))
        y_d(u) = (1/(perc_sloped*(lib_im_v(i)/2)))*x_ind(u);
    end
    for u=1:(perc_sloped_fixed*(lib_im_v(i)/2))
        y_d_fixed(u) = (1/(perc_sloped_fixed*(lib_im_v(i)/2)))*x_ind(u);
    end
    %     
    %     x_ind = linspace(0,lib_im_v(i)/2,lib_im_v(i)/2);  %triangular window.
    %     y_d = (-1/(lib_im_v(i)/2))*x_ind + 1;

    fd(1:lib_im_v(i)/2) = y_d;
    fd(lib_im_v(i)/2+1:lib_im_v(i)) = fliplr(y_d);
    fd_2 = fd*fd';
    window(i).win = fd_2;
    
    fd_fixed(1:lib_im_v(i)/2) = y_d_fixed;
    fd_fixed(lib_im_v(i)/2+1:lib_im_v(i)) = fliplr(y_d_fixed);
    fd_2_fixed = fd_fixed*fd_fixed';
    window(i).win_fixed = fd_2_fixed;
    
    
%     figure(2),mesh(fd_2_fixed)
%     pause
end


for i=1:num_cand_pixels_final
    
    
                if color_render == 0
                    
                    color_path = '../library_images/graffiti_256_black_white';

                else
                    color_path = '../library_images/graffiti_256_color';

                end
                

                image_path = cand_pixels_final(i).file_path;      % read in file path
                
                % if file path uses '\' in path (default for PC), replace
                % with '/' (works on both PC and mac)
              
                for j=1:length(image_path)
                   if (image_path(j) == '\')
                       image_path(j) = '/';
                   end
                end
                
                path = [color_path image_path];
                
%                 % -------- (for mac) convert '\' to '/' ------
%                 pat = '\';
%                 path = regexprep(path, pat, '/');
                
                
                % ---------- read in candidate library image ------------------
                
                Im_lib = imread(path);      % read in library image
                

                DC_adjust = cand_pixels_final(i).DC;
                i_r = cand_pixels_final(i).level;
                j_r = cand_pixels_final(i).res;
                x_r = cand_pixels_final(i).x_cand;
                y_r = cand_pixels_final(i).y_cand;
                scale_est_r = cand_pixels_final(i).scale;
                Theta_r = cand_pixels_final(i).rot;
                lib_im_num_r = cand_pixels_final(i).lib_im;
                cand_pixels_final(i).valid_pix;

%                 x_admin = cand_pixels_final(i).x
%                 y_admin = cand_pixels_final(i).y
                
                perc_DC = 1;        % percentage DC adjusted
%                 DC_adjust = (DC_v(nearest_neighbor_int_index(z))-DC_component)*perc_DC;
                Im_lib = Im_lib-DC_adjust;
                
                
                % ---------- scale cand pixel position according to scale and res ---------------------
                x_r = round(x_r*2^(scaling_constant_v(rendering_level)-(i_r+j_r)));
                y_r = round(y_r*2^(scaling_constant_v(rendering_level)-(i_r+j_r)));
                                    
%                 radius_cand =
%                 ((lib_im_v(i)/2)/scale_est)*(1-perc_sloped);
                % ---------- read in candidate library image ------------------
%                 Im_lib = imread([files(lib_im_num_r).name]);      % read in library image
                
                % -------resize library image for level -------------
                Im_lib_tmp = imresize(Im_lib, [lib_im_v(i_r) lib_im_v(i_r)]);
    

                
                % ------- crop analysis window -------------------------
                xmin = x_r - lib_im_v(i_r)/2;
                ymin = y_r - lib_im_v(i_r)/2;
                width = lib_im_v(i_r)-1;
                height = lib_im_v(i_r)-1;

                rect = [xmin ymin width height];
                Im_target_tile = imcrop(Render_target,rect); 
                
%                 Im_target_tile_masked = zeros([lib_im_v(i_r) lib_im_v(i_r)]);
                mask = zeros([lib_im_v(i_r) lib_im_v(i_r)]);
                
                % ---------- matrix for backing up Render target pixels -----------------
                Render_target_backup = zeros([lib_im_v(i_r) lib_im_v(i_r) 3]);
    
                % --------- scale image ----------------
    
                I_sc_tmp = imresize(Im_lib_tmp, 1/scale_est_r);
                I_sc_tmp_size = size(I_sc_tmp);

                tmp_height = I_sc_tmp_size(1);
                tmp_width = I_sc_tmp_size(2);

                radius = ((lib_im_v(i_r)/2)/scale_est_r)*(1-perc_sloped);

                fd_2 = window(i_r).win;
                fd_2 = imresize(fd_2,[I_sc_tmp_size(1) I_sc_tmp_size(2)]);
                mask_tmp = ones([I_sc_tmp_size(1) I_sc_tmp_size(2)]);

                I_sc = zeros([lib_im_v(i_r) lib_im_v(i_r) 3]);
%                 I_comb = zeros([lib_im_v(i_r) lib_im_v(i_r) 3]);

                I_sc(round(lib_im_v(i_r)/2 - tmp_height/2)+1:round(lib_im_v(i_r)/2 - tmp_height/2)+tmp_height,round(lib_im_v(i_r)/2 - tmp_width/2)+1:round(lib_im_v(i_r)/2 - tmp_width/2)+tmp_width, :) = I_sc_tmp;

            %     mask(round(lib_im_v(i)/2 - tmp_height/2)+1:round(lib_im_v(i)/2 - tmp_height/2)+tmp_height,round(lib_im_v(i)/2 - tmp_width/2)+1:round(lib_im_v(i)/2 - tmp_width/2)+tmp_width) = mask_tmp;
                mask(round(lib_im_v(i_r)/2 - tmp_height/2)+1:round(lib_im_v(i_r)/2 - tmp_height/2)+tmp_height,round(lib_im_v(i_r)/2 - tmp_width/2)+1:round(lib_im_v(i_r)/2 - tmp_width/2)+tmp_width) = fd_2;

                % -------Rotate image back by theta estimate --------

                R1 = imrotate(I_sc, -Theta_r, 'bilinear', 'crop');  
                mask = imrotate(mask, -Theta_r, 'bilinear', 'crop');

                fd_2_tmp  = window(i_r).win_fixed;
                mask = mask.*fd_2_tmp;

            %     pause
            %     window(i).win_fixed
            %     mask_t = mask*window(i).win;
% 
%                 alpha = 0.5;
%                 I_comb = (alpha)*double(Im_target_tile) + (1-alpha)*R1;
%                 

                % ----------------- Render match ---------------------
                for u= 1:lib_im_v(i_r)%ymin:(ymin+height)
                    for v = 1:lib_im_v(i_r)%xmin:(xmin+width)

                        Render_target_backup(u,v) = Render_target(ymin+u-1,xmin+v-1);
                        if (mask(u,v) > .01)
                            Render_target(ymin+u-1,xmin+v-1,1) = uint8(R1(u,v,1)*mask(u,v) + (1-mask(u,v))*Render_target(ymin+u-1,xmin+v-1,1));
                            Render_target(ymin+u-1,xmin+v-1,2) = uint8(R1(u,v,2)*mask(u,v) + (1-mask(u,v))*Render_target(ymin+u-1,xmin+v-1,2));
                            Render_target(ymin+u-1,xmin+v-1,3) = uint8(R1(u,v,3)*mask(u,v) + (1-mask(u,v))*Render_target(ymin+u-1,xmin+v-1,3));

                        end

                    end
                end               
                
%                 figure(2),subplot(1,3,1),imshow(uint8(Render_target_backup))
%                 subplot(1,3,2),imshow(Render_target(max(y-sq_center_disp(1),1):min(y+sq_center_disp(1),size_render_target(1)), max(x-sq_center_disp(2),1):min(x+sq_center_disp(2),size_render_target(2)))); 
%                 subplot(1,3,3),imshow(Render_target)   
%                 figure(2),imshow(Render_target)
% 
                  figure(2),imshow(Render_target)
                drawnow
%                 pause

end

imwrite(Render_target,'fractal_mosaic_graffiti_color','jpg','quality',100);


