
function polar = polar_conversion(A)


A_dim = size(A);        % get dimensions of A
center = A_dim/2;       % get center of image coordinates


% ---------- calculate polar coordinates -------------
theta = linspace(0,2*pi,A_dim(1)+1); theta(end) = [];
% d = min([A_dim(1)-center(1) center(1)-1 A_dim(2)-center(2) center(2)-1]);
rho = linspace(0, center(1)-1,A_dim(2))';

% convert polar coordinates to cartesian coordinates and center
xx = rho*cos(theta) + center(1);
yy = rho*sin(theta) + center(2);
            

xx = double(xx);
yy = double(yy);


polar=interp2(double(A),xx,yy);




