
clear all
close all

color = 0;
% ----------------------------- get jpeg file paths --------------------

'getting image paths...'

                                if color ==0
                                    path = ['../library_images/graffiti_256_black_white/']; 
                                else
                                    path = ['C:\Americano\library_images\graffiti_256_color\'];
                                end


                                % files = dir('C:\Image_registration\flickr_spider\graffiti_library\*.jpg');                    % get file names
                                directories = dir(path);                    % get directory names

                                num_files = 0;
                                file_count = 0;

                                dir_temp = directories(3).name;        % get first directory name
                                files = dir([path,dir_temp,'/*.jpg']);     % get file names for first directory
                                file_count = length(files);

                                % add directory path to jpeg files name
                                for j=1:length(files)
                                    files(j).name = [path,dir_temp,'/',files(j).name];
                                end

                                for i=2:(length(directories)-2)         % offset by 2 because first two entries are '.' and '..'


                                    dir_temp = directories(i+2).name;        % get next directory name

                                    files_temp = dir([path,dir_temp,'/*.jpg']);     % get file names for given directory

                                    % add directory path to jpeg files name
                                    for j=1:length(files_temp)
                                        files_temp(j).name = [path,dir_temp,'/',files_temp(j).name];
                                    end



                                    % concatenate file paths from next directory to existing 
                                    files((file_count+1):(file_count+length(files_temp))) = files_temp;


                                    file_count = file_count+length(files_temp);
                                %     pause
                                end


% bins = 16;
% hist_x = [(255/bins)/2:255/bins:(255-(255/bins)/2)];
% hist_matrix = zeros(length(files),bins);

radial_freq = 6;
angular_freq = 6;
vector_len = radial_freq*angular_freq;
gfd_matrix = zeros(length(files),vector_len);
%   gfd_matrix = zeros(8000,vector_len);
  
size_v = [128 128];

avg_gfd = zeros(radial_freq,angular_freq);

for i=1:length(files)
    
    i
    
    
    Im_lib = imread([files(i).name]);      % read in library image
    
    Im_lib = imresize(Im_lib,size_v);    % resize image to 128
    
%     size_Im_lib = size(Im_lib);
%     
%     % ------ reshape Im_lib into 1D array ------
%     Im_lib_array = reshape(Im_lib,size_Im_lib(1)*size_Im_lib(2),1);
% 
%     histo = hist(double(Im_lib_array),hist_x);
        
    Im_lib_polar = polar_conversion(Im_lib);
    Im_lib_polar_FFT = abs(fftshift(fft2(Im_lib_polar)));
    
    DC = Im_lib_polar_FFT(size_v(1)/2+1,size_v(2)/2+1);
%     energy_norm = sum(sum(Im_lib_polar_FFT));
    
    % --------------- normalize coefs ------------------------
%     Im_lib_polar_FFT(size_v(1)/2+1,size_v(2)/2+1) = Im_lib_polar_FFT(size_v(1)/2+1,size_v(2)/2+1)/(size_v(1)*size_v(2));
    
    Im_lib_polar_FFT = Im_lib_polar_FFT./DC;
%     Im_lib_polar_FFT = Im_lib_polar_FFT./energy_norm;
    
    
%     Im_lib_polar_FFT(size_v(1)/2+1,size_v(2)/2+1) = DC;
    
    
    
    center_gfd = [size_v(1)/2+1 size_v(2)/2+1];
    
    gfd = Im_lib_polar_FFT(center_gfd(1):(center_gfd(1)+angular_freq-1),center_gfd(2):(center_gfd(2)+radial_freq-1));
    
    avg_gfd = avg_gfd + gfd;
    
    
%     figure(1),subplot(1,2,1),imshow(uint8(Im_lib))
%     subplot(1,2,2),mesh(gfd)
%     
%     pause
    
%     I1_gfd = fourier_mellin(Im_lib);

%     hu_moment = humoments(Im_lib);
    gfd_matrix(i,:) = gfd(:);
    
    
%         figure(1),subplot(2,1,1),imshow(Im_lib)
%     subplot(2,1,2),imshow(Im_lib)
%     subplot(3,1,3),mesh(I1_fm)
    
    
%     figure(1),subplot(1,2,1),imshow(Im_lib)
%     subplot(1,2,2),mesh(I1_fm);
%     pause
        
%     subplot(1,2,1),imshow(Im_lib)
%     subplot(1,2,2),plot(histo)

    
end
% pause

gfd_matrix = single(gfd_matrix);
save('gfd_matrix_graffiti_128', 'gfd_matrix')
% save('gfd_matrix_SF_128', 'gfd_matrix')
% save('avg_gfd_3045', 'avg_gfd')

% avg_gfd = gfd_matrix(1,:);
% 
% for i=2:4846
%     avg_gfd = avg_gfd+ gfd_matrix(i,:);
%     
% end




% for i=1:1000%length(files)
%     i
%     
%     fm = fm_matrix(i,:);
%     
% %     for j=1:1000
%         
%         
%         [nearest_neighbor_fm neighbor_distances_fm] = kNearestNeighbors(fm_matrix(1:1000,:), fm, 1000);
%         min_fm_dist = neighbor_distances_fm(2);
%         max_fm_dist = neighbor_distances_fm(end);
% 
% %     end
%     
% end

% fm_matrix = single(fm_matrix);
% save('gfd_matrix_graffiti_128', 'gfd_matrix')
% load('hist_matrix_graffiti');


% [index_vals,vector_vals,final_nodes] = kd_knn(tree,point,k,plot_stuff,node_number)



