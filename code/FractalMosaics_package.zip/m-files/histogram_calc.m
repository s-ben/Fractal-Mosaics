
clear all
close all

% ----------------------------- get jpeg file paths --------------------

'getting image paths...'

path = ['../library_images/graffiti_256_black_white/'];            % path to library images

% files = dir('C:\Image_registration\flickr_spider\graffiti_library\*.jpg');                    % get file names
directories = dir(path);                    % get directory names

num_files = 0;
file_count = 0;

dir_temp = directories(3).name;        % get first directory name
files = dir([path,dir_temp,'/*.jpg']);     % get file names for first directory
file_count = length(files);

% add directory path to jpeg files name
for j=1:length(files)
    files(j).name = [path,dir_temp,'/',files(j).name];
end
    
for i=2:(length(directories)-2)         % offset by 2 because first two entries are '.' and '..'
 
    
    dir_temp = directories(i+2).name;        % get next directory name

    files_temp = dir([path,dir_temp,'/*.jpg']);     % get file names for given directory
    
    % add directory path to jpeg files name
    for j=1:length(files_temp)
        files_temp(j).name = [path,dir_temp,'/',files_temp(j).name];
    end
    
        

    % concatenate file paths from next directory to existing 
    files((file_count+1):(file_count+length(files_temp))) = files_temp;
  

    file_count = file_count+length(files_temp);
%     pause
end

bins = 16;
hist_x = [(255/bins)/2:255/bins:(255-(255/bins)/2)];
hist_matrix = zeros(length(files),bins);

            

for i=1:length(files)
    
    i
    
    
    Im_lib = imread([files(i).name]);      % read in library image
    
    Im_lib = imresize(Im_lib,[128 128]);    % resize image to 128
    
    size_Im_lib = size(Im_lib);
    
    % ------ reshape Im_lib into 1D array ------
    Im_lib_array = reshape(Im_lib,size_Im_lib(1)*size_Im_lib(2),1);

    histo = hist(double(Im_lib_array),hist_x);
        
    hist_matrix(i,:) = histo;
        
%     subplot(1,2,1),imshow(Im_lib)
%     subplot(1,2,2),plot(histo)

    
end

save('hist_matrix_graffiti_128', 'hist_matrix')
% load('hist_matrix_graffiti');






